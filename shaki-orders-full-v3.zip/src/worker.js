const json = (data, status=200) => new Response(JSON.stringify(data), {
  status,
  headers: {"content-type":"application/json; charset=utf-8","cache-control":"no-store"}
});

const now = () => new Date().toISOString();

function cors(resp) {
  const h = new Headers(resp.headers);
  h.set("Access-Control-Allow-Origin", "*");
  h.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
  h.set("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS");
  return new Response(resp.body, {status:resp.status, headers:h});
}

function b64u(buf) {
  return btoa(String.fromCharCode(...new Uint8Array(buf)))
    .replaceAll("+","-").replaceAll("/","_").replaceAll("=","");
}
function b64uDecode(s) {
  s=s.replaceAll("-","+").replaceAll("_","/");
  while(s.length%4)s+="=";
  return Uint8Array.from(atob(s),c=>c.charCodeAt(0));
}
async function hmac(secret, text) {
  const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);
  return b64u(await crypto.subtle.sign("HMAC",key,new TextEncoder().encode(text)));
}
async function makeSession(env) {
  const payload=b64u(new TextEncoder().encode(JSON.stringify({admin:true,exp:Date.now()+1000*60*60*12})));
  return payload+"."+await hmac(env.SESSION_SECRET,payload);
}
async function isAdmin(req,env) {
  const c=req.headers.get("Cookie")||"";
  const m=c.match(/shaki_session=([^;]+)/);
  if(!m)return false;
  const [payload,sig]=m[1].split(".");
  if(!payload||!sig)return false;
  const expected=await hmac(env.SESSION_SECRET,payload);
  if(sig!==expected)return false;
  try { return JSON.parse(new TextDecoder().decode(b64uDecode(payload))).exp>Date.now(); } catch { return false; }
}
function clean(s){ return String(s??"").trim(); }
function money(n){ return Math.round(Number(n)*100)/100; }

async function seed(env) {
  const count=await env.DB.prepare("SELECT COUNT(*) c FROM menu_categories").first();
  if(count?.c) return;
  const cats=[
    ["بيتزا","pizza",1],["شاورما","shawarma",2],["برجر","burger",3],["معجنات","pastry",4]
  ];
  for(const c of cats) await env.DB.prepare("INSERT INTO menu_categories(name,slug,sort_order) VALUES(?,?,?)").bind(...c).run();
  const catRows=await env.DB.prepare("SELECT id,slug FROM menu_categories").all();
  const ids=Object.fromEntries(catRows.results.map(x=>[x.slug,x.id]));
  const items=[
    [ids.pizza,"بيتزا رانش","",32,"🍕",1],
    [ids.pizza,"بيتزا ديناميت","",34,"🍕",2],
    [ids.pizza,"بيتزا ببروني","",32,"🍕",3],
    [ids.pizza,"بيتزا ناتشوز","",36,"🍕",4],
    [ids.shawarma,"كرسبي شاورما","",28,"🌯",1],
    [ids.shawarma,"شاورما عادي","",18,"🌯",2],
    [ids.burger,"برجر شاكي","",29,"🍔",1],
    [ids.pastry,"معجنات مشكلة","",22,"🥐",1]
  ];
  for(const x of items) await env.DB.prepare("INSERT INTO menu_items(category_id,name,description,price,image,sort_order) VALUES(?,?,?,?,?,?)").bind(...x).run();
  const zones=[["المنطقة 1",5,0,null,1],["المنطقة 2",7,0,null,2],["المنطقة 3",10,0,null,3],["المنطقة 4",15,0,null,4]];
  for(const z of zones) await env.DB.prepare("INSERT INTO delivery_zones(name,fee,min_order,free_delivery_from,sort_order) VALUES(?,?,?,?,?)").bind(...z).run();
  await env.DB.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES('restaurant_name',?)").bind(env.RESTAURANT_NAME||"شاكي").run();
  await env.DB.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES('whatsapp','')").run();
}

async function api(req, env, url) {
  await seed(env);
  const path=url.pathname.replace(/^\/api/,"")||"/";
  if(req.method==="GET" && path==="/menu"){
    const cats=await env.DB.prepare("SELECT * FROM menu_categories WHERE active=1 ORDER BY sort_order,id").all();
    const items=await env.DB.prepare("SELECT * FROM menu_items WHERE active=1 ORDER BY sort_order,id").all();
    return json({categories:cats.results,items:items.results});
  }
  if(req.method==="GET" && path==="/zones"){
    const z=await env.DB.prepare("SELECT * FROM delivery_zones WHERE active=1 ORDER BY sort_order,id").all();
    return json(z.results);
  }
  if(req.method==="POST" && path==="/check-coupon"){
    const b=await req.json(); const code=clean(b.code).toUpperCase(); const subtotal=Number(b.subtotal)||0;
    const c=await env.DB.prepare("SELECT * FROM coupons WHERE code=? AND active=1").bind(code).first();
    if(!c || (c.expires_at && new Date(c.expires_at)<=new Date()) || subtotal<Number(c.min_order)) return json({error:"الكود غير صالح أو لا ينطبق على الطلب"},400);
    const discount=c.type==="percent"?subtotal*(Number(c.value)/100):Number(c.value);
    return json({ok:true,discount:money(Math.min(discount,subtotal))});
  }
  if(req.method==="POST" && path==="/orders"){
    const body=await req.json();
    const customer=body.customer||{};
    const items=Array.isArray(body.items)?body.items:[];
    if(!clean(customer.name)||!clean(customer.phone)||!clean(customer.address)||!items.length) return json({error:"أكمل بيانات الطلب"},400);
    const ids=items.map(x=>Number(x.id)).filter(Boolean);
    const placeholders=ids.map(()=>"?").join(",");
    const dbItems=await env.DB.prepare(`SELECT id,name,price FROM menu_items WHERE active=1 AND id IN (${placeholders})`).bind(...ids).all();
    const map=Object.fromEntries(dbItems.results.map(x=>[x.id,x]));
    let subtotal=0; const finalItems=[];
    for(const x of items){
      const row=map[Number(x.id)]; const qty=Math.max(1,Math.min(99,Number(x.qty)||1));
      if(!row) continue;
      subtotal += Number(row.price)*qty;
      finalItems.push({id:row.id,name:row.name,price:Number(row.price),qty});
    }
    if(!finalItems.length)return json({error:"الأصناف غير متاحة"},400);
    let deliveryFee=0, zoneName="";
    if(body.zone_id){
      const z=await env.DB.prepare("SELECT * FROM delivery_zones WHERE id=? AND active=1").bind(Number(body.zone_id)).first();
      if(z){deliveryFee=Number(z.fee); zoneName=z.name;}
    }
    let discount=0;
    const code=clean(body.coupon).toUpperCase();
    if(code){
      const c=await env.DB.prepare("SELECT * FROM coupons WHERE code=? AND active=1").bind(code).first();
      if(c && (!c.expires_at || new Date(c.expires_at)>new Date()) && subtotal>=Number(c.min_order)){
        discount=c.type==="percent"?subtotal*(Number(c.value)/100):Number(c.value);
        discount=Math.min(discount,subtotal);
      }
    }
    const total=money(subtotal+deliveryFee-discount);
    const stamp=now();
    const orderNo="S"+String(Date.now()).slice(-7);
    const r=await env.DB.prepare(`INSERT INTO orders(order_no,customer_name,phone,address,zone_id,zone_name,payment_method,notes,subtotal,delivery_fee,discount,total,status,created_at,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(orderNo,clean(customer.name),clean(customer.phone),clean(customer.address),body.zone_id?Number(body.zone_id):null,zoneName,clean(body.payment_method)||"cash",clean(body.notes),money(subtotal),money(deliveryFee),money(discount),total,"new",stamp,stamp).run();
    const orderId=r.meta.last_row_id;
    for(const it of finalItems) await env.DB.prepare("INSERT INTO order_items(order_id,item_id,name,price,qty) VALUES(?,?,?,?,?)").bind(orderId,it.id,it.name,it.price,it.qty).run();
    return json({ok:true,order:{id:orderId,order_no:orderNo,total,delivery_fee:deliveryFee,discount,status:"new"}},201);
  }
  if(path==="/admin/login" && req.method==="POST"){
    const b=await req.json();
    if(clean(b.password)!==clean(env.ADMIN_PASSWORD)) return json({error:"الرمز غير صحيح"},401);
    const token=await makeSession(env);
    return new Response(JSON.stringify({ok:true}),{headers:{
      "content-type":"application/json; charset=utf-8","set-cookie":`shaki_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=43200`
    }});
  }
  if(path==="/admin/logout" && req.method==="POST"){
    return new Response(JSON.stringify({ok:true}),{headers:{"content-type":"application/json","set-cookie":"shaki_session=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax"}});
  }
  if(!(await isAdmin(req,env))) return json({error:"غير مصرح"},401);

  if(req.method==="GET" && path==="/admin/orders"){
    const orders=await env.DB.prepare("SELECT * FROM orders ORDER BY id DESC LIMIT 200").all();
    for(const o of orders.results){
      const its=await env.DB.prepare("SELECT * FROM order_items WHERE order_id=? ORDER BY id").bind(o.id).all();
      o.items=its.results;
    }
    return json(orders.results);
  }
  if(req.method==="PATCH" && path.startsWith("/admin/orders/")){
    const id=Number(path.split("/").pop()); const b=await req.json();
    const allowed=["new","accepted","preparing","ready","out_for_delivery","completed","cancelled"];
    if(!allowed.includes(b.status))return json({error:"حالة غير صحيحة"},400);
    await env.DB.prepare("UPDATE orders SET status=?,updated_at=? WHERE id=?").bind(b.status,now(),id).run();
    return json({ok:true});
  }
  if(req.method==="GET" && path==="/admin/stats"){
    const today=new Date().toISOString().slice(0,10);
    const r=await env.DB.prepare(`SELECT COUNT(*) orders, COALESCE(SUM(total),0) sales, COALESCE(AVG(total),0) avg FROM orders WHERE substr(created_at,1,10)=? AND status!='cancelled'`).bind(today).first();
    const p=await env.DB.prepare("SELECT COUNT(*) c FROM orders WHERE status IN ('new','accepted','preparing','ready','out_for_delivery')").first();
    return json({orders:Number(r.orders||0),sales:money(r.sales||0),avg:money(r.avg||0),pending:Number(p.c||0)});
  }
  if(req.method==="GET" && path==="/admin/menu"){
    const cats=await env.DB.prepare("SELECT * FROM menu_categories ORDER BY sort_order,id").all();
    const items=await env.DB.prepare("SELECT * FROM menu_items ORDER BY sort_order,id").all();
    return json({categories:cats.results,items:items.results});
  }
  if(req.method==="PUT" && path.startsWith("/admin/menu/items/")){
    const id=Number(path.split("/").pop()), b=await req.json();
    await env.DB.prepare("UPDATE menu_items SET name=?,description=?,price=?,active=?,sort_order=? WHERE id=?")
      .bind(clean(b.name),clean(b.description),money(b.price),b.active?1:0,Number(b.sort_order||0),id).run();
    return json({ok:true});
  }
  if(req.method==="POST" && path==="/admin/menu/items"){
    const b=await req.json();
    await env.DB.prepare("INSERT INTO menu_items(category_id,name,description,price,image,active,sort_order) VALUES(?,?,?,?,?,?,?)")
      .bind(Number(b.category_id),clean(b.name),clean(b.description),money(b.price),clean(b.image),1,Number(b.sort_order||0)).run();
    return json({ok:true});
  }
  if(req.method==="GET" && path==="/admin/zones") {
    const z=await env.DB.prepare("SELECT * FROM delivery_zones ORDER BY sort_order,id").all(); return json(z.results);
  }
  if(req.method==="PUT" && path.startsWith("/admin/zones/")){
    const id=Number(path.split("/").pop()),b=await req.json();
    await env.DB.prepare("UPDATE delivery_zones SET name=?,fee=?,min_order=?,free_delivery_from=?,active=?,sort_order=? WHERE id=?")
      .bind(clean(b.name),money(b.fee),money(b.min_order),b.free_delivery_from===""?null:money(b.free_delivery_from),b.active?1:0,Number(b.sort_order||0),id).run();
    return json({ok:true});
  }
  if(req.method==="GET" && path==="/admin/coupons"){
    const c=await env.DB.prepare("SELECT * FROM coupons ORDER BY id DESC").all(); return json(c.results);
  }
  if(req.method==="POST" && path==="/admin/coupons"){
    const b=await req.json();
    try{
      await env.DB.prepare("INSERT INTO coupons(code,type,value,min_order,active,expires_at) VALUES(?,?,?,?,?,?)")
        .bind(clean(b.code).toUpperCase(),b.type==="fixed"?"fixed":"percent",money(b.value),money(b.min_order),b.active?1:0,clean(b.expires_at)||null).run();
      return json({ok:true});
    }catch(e){return json({error:"الكود موجود مسبقًا"},400)}
  }
  return json({error:"Not found"},404);
}

export default {
  async fetch(req, env) {
    if(req.method==="OPTIONS") return cors(new Response(null,{status:204}));
    const url=new URL(req.url);
    try{
      const resp=url.pathname.startsWith("/api/") ? await api(req,env,url) : await env.ASSETS.fetch(req);
      return cors(resp);
    }catch(e){
      return cors(json({error:"حدث خطأ في الخادم",detail:String(e?.message||e)},500));
    }
  }
};
